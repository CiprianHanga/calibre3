# =======================================================================================
# IMPORTS
# =======================================================================================
import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import *
from tkinter import filedialog, messagebox

global df

""" requires openpyxl """


# =======================================================================================
# FUNCTIONS
# =======================================================================================

def getCSV():
    global df
    
    try:
        import_file_path = filedialog.askopenfilename()
        df = pd.read_csv(import_file_path, encoding = 'utf-16', sep = "\t", low_memory = False)
        
        # Fix for the invalid character error
        df = df.applymap(lambda x: x.encode('unicode_escape').
            decode('utf-8') if isinstance(x, str) else x)

        print("CSV File loaded.")

        message = messagebox.showinfo("Info", "CSV File loaded.")
    except:
        print("No file loaded.")
    print()


"""
def convertToExcel():
    global df
    
    export_file_path = filedialog.asksaveasfilename(defaultextension='.xlsx')
    print("Processing, please wait...")

    # Fix for the invalid character error
    df = df.applymap(lambda x: x.encode('unicode_escape').
        decode('utf-8') if isinstance(x, str) else x)

    df.to_excel(export_file_path, index = None, header=True)
    print("CSV file converted to XLSX format.")
    print()

    message = messagebox.showinfo("Info", "CSV File converted to XLSX format.")
"""

def filterQuickWins():
	
    global df_qwleafs
    global df_qwkws
    global df_qwdsc
    global df_qwbrs
    global df_qwbp1
    global df_qwbp2
    global df_qwbp3
    global df_qwimgs
    global df_qwimgz

    global df_step1
    global df_step2
    global df_step3
    global df_step4
    global df_step5
    global df_step6
    global df_step7
    global df_step8

    # =========================== Full Score Quick Wins (+20/15) ========================

    print("Processing, please wait...")
    # 1st filter: Leaf Node Quick Wins (+20)
    df_qwleafs = df.query("has_leaf_node==0 & idq_score_gl >= 50")
    # merge the two sets
    df_step1 = df.merge(df_qwleafs.drop_duplicates(), how='left', indicator=True)
    # slice the second df from the first (keep only the unprocessed rows)
    df_step1 = df_step1[df_step1['_merge'] == 'left_only']
    # remove the _merge column
    df_step1 = df_step1.drop(labels='_merge', axis=1)

    # 2nd filter: Keywords Quick Wins (+15)
    df_qwkws = df_step1.query("has_keywords==0 & idq_score_gl >= 55")
    df_step2 = df_step1.merge(df_qwkws.drop_duplicates(), how='left', indicator=True)
    df_step2 = df_step2[df_step2['_merge'] == 'left_only']
    df_step2 = df_step2.drop(labels='_merge', axis=1)

    # 3rd filter: Description Quick Wins (+15)
    df_qwdsc = df_step2.query("has_description==0 & idq_score_gl >= 55")
    df_step3 = df_step2.merge(df_qwdsc.drop_duplicates(), how='left', indicator=True)
    df_step3 = df_step3[df_step3['_merge'] == 'left_only']
    df_step3 = df_step3.drop(labels='_merge', axis=1)

    # 4th filter: Brand Quick Wins (+15)
    df_qwbrs = df_step3.query("has_brand==0 & idq_score_gl >= 55")
    df_step4 = df_step3.merge(df_qwbrs.drop_duplicates(), how='left', indicator=True)
    df_step4 = df_step4[df_step4['_merge'] == 'left_only']
    df_step4 = df_step4.drop(labels='_merge', axis=1)

    # 5th filter: Bullet Points Quick Wins (only those with full score: +15)
    df_qwbp1 = df_step4.query("bullet_points_count in [0, 'NaN'] & idq_score_gl >= 55")
    df_step5 = df_step4.merge(df_qwbp1.drop_duplicates(), how='left', indicator=True)
    df_step5 = df_step5[df_step5['_merge'] == 'left_only']
    df_step5 = df_step5.drop(labels='_merge', axis=1)

    # =========================== Partial Score Quick Wins (+12.5 and lower) ============

    # 6th filter: Bullet Points Quick Wins (partial score: +12.5)
    df_qwbp2 = df_step5.query("bullet_points_count==1 & idq_score_gl >= 57.5")
    df_step6 = df_step5.merge(df_qwbp2.drop_duplicates(), how='left', indicator=True)
    df_step6 = df_step6[df_step6['_merge'] == 'left_only']
    df_step6 = df_step6.drop(labels='_merge', axis=1)

    # 7th filter: Bullet Points Quick Wins (partial score: +7.5)
    df_qwbp3 = df_step6.query("bullet_points_count in [2, 3] & idq_score_gl >= 62.5")
    df_step7 = df_step6.merge(df_qwbp3.drop_duplicates(), how='left', indicator=True)
    df_step7 = df_step7[df_step7['_merge'] == 'left_only']
    df_step7 = df_step7.drop(labels='_merge', axis=1)

    # 8th filter: Image 3p-to-Retail Quick Wins (+5)
    df_qwimgs = df_step7.query("qty_website_images in [1, 2, 3] & idq_score_gl >= 65")
    df_step8 = df_step7.merge(df_qwimgs.drop_duplicates(), how='left', indicator=True)
    df_step8 = df_step8[df_step8['_merge'] == 'left_only']
    df_step8 = df_step8.drop(labels='_merge', axis=1)

    print("Filters successfully applied.")
    print()

    message = messagebox.showinfo("Info", "Filters successfully applied.")


def filterBPs_DSC():
    
    global df_qwdsc2
    global df_qwbp1_1b
    global df_qwbp2_1b
    global df_qwbp3_1b
    
    global df_step1b
    global df_step2b
    global df_step3b
    global df_step4b
    

    # =========================== Only DSC-BPs Quick Wins (+20/15/12.5/7.5) =============

    print("Processing, please wait...")
    # 3rd filter: Description Quick Wins (+15)
    df_qwdsc2 = df.query("has_description==0 & idq_score_gl >= 55")
    df_step1b = df.merge(df_qwdsc2.drop_duplicates(), how='left', indicator=True)
    df_step1b = df_step1b[df_step1b['_merge'] == 'left_only']
    df_step1b = df_step1b.drop(labels='_merge', axis=1)

    # 7th filter: Bullet Points Quick Wins (partial score: +7.5)
    df_qwbp1_1b = df_step1b.query("bullet_points_count in [2, 3] & idq_score_gl >= 62.5")
    df_step2b = df_step1b.merge(df_qwbp1_1b.drop_duplicates(), how='left', indicator=True)
    df_step2b = df_step2b[df_step2b['_merge'] == 'left_only']
    df_step2b = df_step2b.drop(labels='_merge', axis=1)

    # 6th filter: Bullet Points Quick Wins (partial score: +12.5)
    df_qwbp2_1b = df_step2b.query("bullet_points_count==1 & idq_score_gl >= 57.5")
    df_step3b = df_step2b.merge(df_qwbp2_1b.drop_duplicates(), how='left', indicator=True)
    df_step3b = df_step3b[df_step3b['_merge'] == 'left_only']
    df_step3b = df_step3b.drop(labels='_merge', axis=1)

    # 5th filter: Bullet Points Quick Wins (only those with full score: +15)
    df_qwbp3_1b = df_step3b.query("bullet_points_count in [0, 'NaN'] & idq_score_gl >= 55")
    df_step4b = df_step3b.merge(df_qwbp3_1b.drop_duplicates(), how='left', indicator=True)
    df_step4b = df_step4b[df_step4b['_merge'] == 'left_only']
    df_step4b = df_step4b.drop(labels='_merge', axis=1)


    print("Filters successfully applied.")
    print()

    message = messagebox.showinfo("Info", "Filters successfully applied.")



# =========================== All-Filters Export Functions ==========================


def exporttoExcelGlobalFile():
    global df_all

    # merge all the processed DataFrames into one
    pdList = [df_qwleafs, df_qwkws, df_qwdsc, df_qwbrs, df_qwbp1, df_qwbp2, df_qwbp3, df_qwimgs]
    df_all = pd.concat(pdList)

    print("DataFrames merge completed, processing...")

    # create excel writer object
    writer = pd.ExcelWriter('df_all.xlsx')
    # write dataframe to excel
    df_all.to_excel(writer, index=False)
    # save the excel
    writer.save()

    print("COMPLETED export to GLOBAL Excel file.")
    print()

    message = messagebox.showinfo("Info", "Finished exporting to GLOBAL Excel file.")

def exporttoExcelSeparateFiles():
    print("Processing, please wait...")

    writer = pd.ExcelWriter('1_df_qwleafs.xlsx')
    df_qwleafs.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Leafs results exported to single file.")

    writer = pd.ExcelWriter('2_df_qwkws.xlsx')
    df_qwkws.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Keywords results exported to single file.")

    writer = pd.ExcelWriter('3_df_qwdsc.xlsx')
    df_qwdsc.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Description results exported to single file.")

    writer = pd.ExcelWriter('4_df_qwbrs.xlsx')
    df_qwbrs.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Brand results exported to single file.")

    writer = pd.ExcelWriter('5_df_qwbp1.xlsx')
    df_qwbp1.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Bullet Points 1 results exported to single file.")

    writer = pd.ExcelWriter('6_df_qwbp2.xlsx')
    df_qwbp2.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Bullet Points 2 results exported to single file.")

    writer = pd.ExcelWriter('7_df_qwbp3.xlsx')
    df_qwbp3.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Bullet Points 3 results exported to single file.")

    writer = pd.ExcelWriter('8_df_qwimgs.xlsx')
    df_qwimgs.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for Images results exported to single file.")
    print()

    print("COMPLETED export to separate Excel files.")
    print()

    message = messagebox.showinfo("Info", "Finished exporting to separate Excel files.")

def exporttoExcelLeftovers():
    print("Processing, please wait...")
    
    writer = pd.ExcelWriter('leftovers.xlsx')
    df_step8.to_excel(writer, index=False)
    writer.save()

    print("Leftover rows exported to Leftover Excel file.")
    print()

    message = messagebox.showinfo("Info", "Leftover rows exported to file.")


# =========================== DSC-BPs Export Functions ==========================


def exporttoExcelGlobalFile2():
    global df_DSC_BPs

    # merge all the processed DataFrames into one
    pdList = [df_qwdsc2, df_qwbp1_1b, df_qwbp2_1b, df_qwbp3_1b]
    df_DSC_BPs = pd.concat(pdList)

    print("DataFrames merge completed, processing...")

    # create excel writer object
    writer = pd.ExcelWriter('df_DSC_BPs_all.xlsx')
    # write dataframe to excel
    df_DSC_BPs.to_excel(writer, index=False)
    # save the excel
    writer.save()

    print("COMPLETED export to GLOBAL Excel file for DSC_BPs.")
    print()

    message = messagebox.showinfo("Info", "Finished exporting to GLOBAL Excel file for DSC_BPs.")

def exporttoExcelSeparateFiles2():
    print("Processing, please wait...")

    writer = pd.ExcelWriter('1_df_DSC_BPs_qwdsc.xlsx')
    df_qwdsc2.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for DSC_BPs: Description results exported to single file.")

    writer = pd.ExcelWriter('2_df_DSC_BPs_qwbp1.xlsx')
    df_qwbp1_1b.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for DSC_BPs: Bullet Points 1 results exported to single file.")

    writer = pd.ExcelWriter('3_df_DSC_BPs_qwbp2.xlsx')
    df_qwbp2_1b.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for DSC_BPs: Bullet Points 2 results exported to single file.")

    writer = pd.ExcelWriter('4_df_DSC_BPs_qwbp3.xlsx')
    df_qwbp3_1b.to_excel(writer, index=False)
    writer.save()
    print("Quick Wins for DSC_BPs: Bullet Points 3 results exported to single file.")


    print("COMPLETED export to separate Excel files.")
    print()

    message = messagebox.showinfo("Info", "Finished exporting to separate Excel files for DSC_BPs.")

def exporttoExcelLeftovers2():
    print("Processing, please wait...")
    
    writer = pd.ExcelWriter('leftovers_DSC_BPs.xlsx')
    df_step4b.to_excel(writer, index=False)
    writer.save()

    print("Leftover rows for DSC_BPs exported to file.")
    print()

    message = messagebox.showinfo("Info", "Leftover rows for DSC_BPs exported to file.")



def exitApplication():
    # MsgBox = tk.messagebox.askquestion ('Exit Application', 
    # 'Are you sure you want to exit the application?',icon = 'warning')
    # if MsgBox == 'yes':
    print("Good Bye!")
    print()
    root.destroy()


# =======================================================================================
# GUI ELEMENTS
# =======================================================================================
root = tk.Tk()
root.title('IDQ WA Tool')
"""
# Fix for the issue with the icon file not being load by pyinstaller
def resource_path(relative_path):
    #Get absolute path to resource, works for dev and for PyInstaller
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

Logo = resource_path("Logo.png")
"""
root.iconphoto(False, tk.PhotoImage(file='green.png'))

# Window positioning
w = root.winfo_reqwidth()
h = root.winfo_reqheight()
ws = root.winfo_screenwidth()
hs = root.winfo_screenheight()
x = (ws/2) - (w/4)
y = (hs/5) - (h/1)
root.geometry('+%d+%d' % (x, y)) ## this part allows you to only change the location

# Window properties
canvas1 = tk.Canvas(
    root, 
	width = 300, 
	height = 600, 
        #bg = 'lightsteelblue2', 
	relief = 'raised')
canvas1.pack()

label1 = tk.Label(
    root, 
	text='IDQ WA Tool')
label1.config(font=('tahoma', 20))
canvas1.create_window(150, 60, window=label1)


# =======================================================================================
# BUTTONS
# =======================================================================================
browseButton_CSV = tk.Button(
    text="            Import CSV File             ", 
	command=getCSV, 
    bg='blue', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 130, window=browseButton_CSV)

"""
saveAsButton_Excel = tk.Button(
    text=' Convert CSV to Excel ', 
	command=convertToExcel, 
    bg='green', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 180, window=saveAsButton_Excel)
"""

filterQuickWinsButton1 = tk.Button(
    root, 
    text='         Filter All Quick Wins         ', 
    command=filterQuickWins, 
    bg='red', 
    fg='black', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 190, window=filterQuickWinsButton1)

exporttoGlobalButton1 = tk.Button(
    root, 
    text='     Export All to GLOBAL file     ', 
    command=exporttoExcelGlobalFile, 
    bg='green', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 230, window=exporttoGlobalButton1)

exporttoSeparateButton1 = tk.Button(
    root, 
    text='    Export All to Separate files    ', 
    command=exporttoExcelSeparateFiles, 
    bg='green', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 270, window=exporttoSeparateButton1)

exportLeftoversButton1 = tk.Button(
    root, 
    text='          Export All Leftovers          ', 
    command=exporttoExcelLeftovers, 
    # bg='green', 
    fg='black', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 310, window=exportLeftoversButton1)


### ================ DSC-BPs buttons ====================================================


filterQuickWinsButton2 = tk.Button(
    root, 
    text='     Filter DSC-BPs Quick Wins     ', 
    command=filterBPs_DSC, 
    bg='red', 
    fg='black', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 370, window=filterQuickWinsButton2)

exporttoGlobalButton2 = tk.Button(
    root, 
    text=' Export DSC-BPs to GLOBAL file ', 
    command=exporttoExcelGlobalFile2, 
    bg='green', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 410, window=exporttoGlobalButton2)

exporttoSeparateButton2 = tk.Button(
    root, 
    text=' Export DSC-BP to Separate files', 
    command=exporttoExcelSeparateFiles2, 
    bg='green', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 450, window=exporttoSeparateButton2)

exportLeftoversButton2 = tk.Button(
    root, 
    text='      Export DSC-BPs Leftovers     ', 
    command=exporttoExcelLeftovers2, 
    # bg='green', 
    fg='black', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 490, window=exportLeftoversButton2)



### ================ LISTBOX ============================================================

"""

# Listbox functions

list_data = []

def clicked():
    global list_data
    listbox.insert(tk.END, content.get())
    list_data.append(content.get())

def delete():
    global list_data
    listbox.delete(0, tk.END)
    list_data = []

def delete_selected():
    try:
        selected = listbox.get(listbox.curselection())
        listbox.delete(tk.ANCHOR)
        list_data.pop(list_data.index(selected))
    except:
        pass

def submit_fields():
        pass
	global df
	print(df.shape)
	df_rbn = pd.DataFrame(df['rbn'].value_counts())
	df_rbn = df_rbn.rename(columns={'rbn':'countif'})
	df = df.join(df_rbn, on='rbn')
	df['allocate'] = ''
	number_user = len(list_data)
	df['allocate'] = df.index.map(lambda i: list_data[(i % number_user)])
	path_to_save = filedialog.asksaveasfilename(defaultextension='.csv')
	df.to_csv(path_to_save, index=False)
	tk.messagebox.showinfo(title=None, message='done')
	print('Done')

# Listbox GUI

content = tk.StringVar()
entry = tk.Entry(root, bg='white', fg='black', textvariable=content)
entry.pack()
button4 = tk.Button(root, text='Add Item to Listbox', command=clicked)
button4.pack()
button_delete_selected = tk.Button(text='Delete Selected Item', command=delete_selected)
button_delete_selected.pack()
button_delete = tk.Button(text='Clear', command=delete)
button_delete.pack()
listbox = tk.Listbox(root, bg='white', fg='black')
listbox.pack()
bquit = tk.Button(root, text='Submit', command=submit_fields)
bquit.pack()

"""


# Exit App button
exitButton = tk.Button(
    root, 
    text='    Exit Application    ', 
	command=exitApplication, 
    bg='brown', 
    fg='white', 
    font=('helvetica', 10, 'bold')
    )
canvas1.create_window(150, 550, window=exitButton)


### ================ RUNTIME ============================================================

root.mainloop()
