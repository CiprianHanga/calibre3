# =======================================================================================
# IMPORTS
# =======================================================================================
""" NOTE: It requires openpyxl. """
import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox

global df


# =======================================================================================
# FUNCTIONS
# =======================================================================================

# Get input, web scrap across MPs Leaf Nodes from BQE and then save results
def getInput():
    global df

    # Get the input file from the user
    try:
        import_file_path = filedialog.askopenfilename()
        df = pd.read_excel(import_file_path)

        # Fix for the invalid character error
        df = df.applymap(lambda x: x.encode('unicode_escape').
                         decode('utf-8') if isinstance(x, str) else x)

        print("Input File loaded, proceeding to the web scraping phase.")

        # message = messagebox.showinfo("Info", "Excel File loaded.")
    except:
        print("No file loaded, check the input file.")
    print()
    

    #TODO: Web scrap across EU5 MPs Leaf Nodes (from BQE) and save the results
    #TODO: Lookup code to match NODE IDs from the resulted files with the 
    #      Leaf Node IDs dictionary (see the Cross_MP_NODE_ID_Index file)
    #TODO: build results to table in the required format (for all MPs)


#TODO: Prepare worksheets for each MP separately
def prepare_worksheet_UK():
    pass


def prepare_worksheet_DE():
    pass


def prepare_worksheet_FR():
    pass


def prepare_worksheet_IT():
    pass


def prepare_worksheet_ES():
    pass


#TODO: Prepare upload file for each process separately
def prepare_upload_MP():
    pass


def prepare_upload_PASIN():
    pass


def exitApplication():
    MsgBox = tk.messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application?',
                                       icon='warning')
    if MsgBox == 'yes':
        print("Good Bye!")
    print()
    root.destroy()


# =======================================================================================
# GUI ELEMENTS
# =======================================================================================
root = tk.Tk()
root.title('Leaf Node Extractor')

# Window positioning
w = root.winfo_reqwidth()
h = root.winfo_reqheight()
ws = root.winfo_screenwidth()
hs = root.winfo_screenheight()
x = (ws / 2) - (w / 4)
y = (hs / 5) - (h / 1)
root.geometry('+%d+%d' % (x, y))  # this part allows you to only change the location

# Window properties
canvas1 = tk.Canvas(
    root,
    width=300,
    height=600,
    bg='lightsteelblue2',
    relief='raised')
canvas1.pack()

label1 = tk.Label(
    root,
    bg='lightsteelblue2',
    text='Leaf Node Extractor')
label1.config(font=('tahoma', 20))
canvas1.create_window(150, 60, window=label1)

# =======================================================================================
# BUTTONS
# =======================================================================================
get_input_Button = tk.Button(
    text="  Download Cross-MP Node IDs  ",
    command=getInput,
    bg='blue',
    fg='white',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 130, window=get_input_Button)

prepare_worksheet_UK_Button = tk.Button(
    root,
    text='Prepare worksheet for the UK MP',
    command=prepare_worksheet_UK,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 190, window=prepare_worksheet_UK_Button)

prepare_worksheet_DE_Button = tk.Button(
    root,
    text='Prepare worksheet for the DE MP',
    command=prepare_worksheet_DE,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 230, window=prepare_worksheet_DE_Button)

prepare_worksheet_FR_Button = tk.Button(
    root,
    text='Prepare worksheet for the FR MP ',
    command=prepare_worksheet_FR,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 270, window=prepare_worksheet_FR_Button)

prepare_worksheet_IT_Button = tk.Button(
    root,
    text=' Prepare worksheet for the IT MP ',
    command=prepare_worksheet_IT,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 310, window=prepare_worksheet_IT_Button)

prepare_worksheet_ES_Button = tk.Button(
    root,
    text='Prepare worksheet for the ES MP',
    command=prepare_worksheet_ES,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 350, window=prepare_worksheet_ES_Button)

# Upload Buttons
prepare_upload_MP_Button = tk.Button(
    root,
    text='   Prepare upload sheet for MP   ',
    command=prepare_upload_MP,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 410, window=prepare_upload_MP_Button)

prepare_upload_PASIN_Button = tk.Button(
    root,
    text='Prepare upload sheet for PASIN ',
    command=prepare_upload_PASIN,
    fg='black',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 450, window=prepare_upload_PASIN_Button)

# Exit App button
exitButton = tk.Button(
    root,
    text='    Exit Application    ',
    command=exitApplication,
    bg='brown',
    fg='white',
    font=('helvetica', 10, 'bold')
)
canvas1.create_window(150, 550, window=exitButton)

# ================ RUNTIME ==============================================================

root.mainloop()
