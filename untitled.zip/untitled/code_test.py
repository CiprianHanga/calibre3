import pandas as pd

# make data frame
data = pd.read_excel(r"c:\Users\ciprh\Downloads\Automotive.xlsx", encoding='ISO-8859-1', index_col="ASIN")

# retrieve rows by gl_name
rows = data.loc["Automotive"]

#print(type(rows))

df = pd.DataFrame(rows)
df.to_excel("c:\Users\ciprh\Downloads\Automotive2.xlsx")